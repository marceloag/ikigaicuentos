<?php get_header(); ?>

	<h2><?php _e('Error 404 - Page Not Found','html5reset'); ?></h2>

<?php get_sidebar(); ?>

<?php get_footer(); ?>