# Wordpress + Tailwind

## Basado en:

### HTML 5 Wordpress Theme

The HTML5 Reset Wordpress theme es un tema en blanco para wordpress que lo encuentran en [HTML5 Reset templates](https://github.com/murtaugh/HTML5-Reset-Wordpress-Theme)

### TailwindCSS

Framework CSS "Utlity First" [Tailwind](https://tailwindcss.com/)

## Acerca de mí:

Soy [Marcelo Aguila](http://www.marceloaguila.com) trabajo y soy co-fundador de [Croop](http://www.croop.cl) y soy un tipo tranquilo, tratando de no hacer mal y ser buen amigo.
