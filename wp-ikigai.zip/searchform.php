<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
    <div class="row collapse">
    	<div class="large-9 columns">
    		<input type="search" id="buscador" name="s" value="" placeholder="Buscar..." /></div>
    	<div class="large-3 columns">
    		<input type="submit" value="" id="botonbuscador" />
    	</div>
    </div>
</form>