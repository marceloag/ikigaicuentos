<!-- FOOTER -->
    <footer class="">
    
      
    </footer>

<?php wp_footer(); ?>

    <script src="<?php bloginfo('template_directory'); ?>/js/app.js"></script>

</body>

</html>
