<div class="navigation">
		<?php if(function_exists('wp_paginate')) {
    wp_paginate();
	} ?>
<!-- 
	<div class="next-posts"><?php next_posts_link('Más Productos') ?></div>
	<div class="prev-posts"><?php previous_posts_link('Volver') ?></div>

	 -->
</div>